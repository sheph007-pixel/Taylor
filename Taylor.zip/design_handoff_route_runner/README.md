# Handoff: Route Runner Redesign

## Overview

Route Runner is a small delivery-routing web app built in React + Firebase for a magazine-delivery operator. This handoff covers a **visual and UX redesign** of the existing app — not new features. The goal is to replace the current generic Material-ish look with a distinct "trucker's logbook" aesthetic (warm ink, cream paper, road-sign amber) and rework the nav, pause, and complete screens to be more informative and actionable.

The existing app already has:
- Firebase Auth, Firestore, and a working data model
- CSV upload → geocoding → nearest-neighbor optimization → cost estimate
- Driver flow (route list → start → Google-Maps-style nav → delivered/skip → complete)
- Admin panel for uploading and managing routes

**This redesign keeps all of that working.** You are reskinning the UI and making targeted UX improvements to specific screens. Data model, routing logic, and Firebase integration should remain as-is.

---

## About the Design Files

The files in `prototype/` are **design references built in HTML + React (via Babel standalone)**. They are prototypes meant to communicate intended look, layout, type, spacing, copy, colors, and interaction — **not production code to copy directly**. In particular:

- They use inline styles with a `const RR = {...}` token object. Your codebase likely already has Tailwind, CSS modules, styled-components, or similar — use that.
- `window.claude.complete`, `window.omelette`, and other preview-only APIs are absent. Ignore anything that looks like it depends on them (nothing in this design does).
- The "map" on the nav screen is a decorative SVG placeholder. In the real app it should be replaced with whatever map library the existing nav screen uses (Google Maps, Mapbox, etc.).
- Mock data in `theme.jsx` (MOCK_ROUTES, MOCK_PROGRESS) is just to make the prototype interactive. Wire real Firestore reads in your implementation.

**Your task:** recreate these designs in the existing Route Runner codebase using its established patterns (React components, its routing library, its state management, its Firebase hooks). Keep the current data layer; swap the presentation.

---

## Fidelity

**High-fidelity.** Colors, type scale, spacing, border radii, shadows, and copy are all final. Implement pixel-close. The only thing that's placeholder-level is the nav-screen map graphic.

---

## Design System

### Colors

Define these as tokens (CSS variables, Tailwind theme extension, or whatever the codebase uses):

```
/* Surfaces */
--ink:          #16130F;   /* near-black, warm — primary dark surface */
--ink-2:        #1F1B16;   /* elevated dark (cards on dark) */
--ink-3:        #2A241C;   /* borders/dividers on dark */
--paper:        #F5EFE3;   /* cream — primary light surface / app bg */
--paper-2:      #EBE3D2;   /* dividers on paper */
--paper-3:      #DDD2BC;   /* muted text on paper */
--line:         #CFC3A8;   /* hairline borders on paper */
--card:         #FFFAEE;   /* slightly warmer than paper — card bg */

/* Accents */
--amber:        #E8A838;   /* PRIMARY — road-sign yellow-orange */
--amber-deep:   #C67E1A;   /* pressed state / bottom-shadow */
--amber-soft:   #FBE9C0;   /* tinted background */
--rust:         #B4522A;   /* alert / skipped / destructive */
--moss:         #4E6B3A;   /* success / delivered */
--moss-deep:    #36502A;   /* pressed success / bottom-shadow */

/* Text */
--text-high:        #16130F;   /* on paper */
--text-mid:         #5C5245;
--text-low:         #847761;
--text-on-ink:      #F5EFE3;
--text-on-ink-2:    rgba(245,239,227,0.72);
--text-on-ink-3:    rgba(245,239,227,0.45);
```

**Usage rules:**
- Default app background is `--paper`.
- Cards on paper use `--card` (slightly warmer) with a `1.5px solid --line` border.
- Dark panels (paused screen, trip ledger, admin top bar) use `--ink` with `--ink-3` dividers.
- `--amber` is the *only* primary accent. Don't introduce blues, purples, or additional accent colors.
- Chunky buttons use a hard bottom-shadow in the deeper variant (`box-shadow: 0 4px 0 var(--amber-deep)` for primary buttons) instead of soft elevation.

### Typography

Three Google Fonts. Import once in the root:

```
https://fonts.googleapis.com/css2?family=Archivo:wght@500;600;700;800;900&family=Inter+Tight:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap
```

Families:
- `"Archivo"` — display / headlines / button labels. Use 700–800 weights, letter-spacing -0.02 to -0.04 on large sizes.
- `"Inter Tight"` — body copy, form fields, list items.
- `"JetBrains Mono"` — numbers, labels, status tags. Always `font-variant-numeric: tabular-nums`.

Scale (driver app, ~376px phone width):
- **Hero display** (greeting, completion headline): Archivo 800, 40–44px, line-height 0.95, letter-spacing -0.02em
- **Screen title** (route name on start): Archivo 800, 28–30px, letter-spacing -0.6px
- **Card heading** (stop name): Archivo 700–800, 19–22px, letter-spacing -0.3 to -0.4px
- **Body**: Inter Tight 400–500, 13–15px, line-height 1.4
- **Button label**: Archivo 800, 15–18px, letter-spacing 0.3px, UPPERCASE
- **Section label / eyebrow**: JetBrains Mono 600, 9.5–11px, letter-spacing 0.8px, UPPERCASE
- **Stat number**: Archivo 800, 20–56px, letter-spacing -0.3 to -0.5px, tabular-nums
- **Stat label under stat**: JetBrains Mono 600, 9.5–10px, letter-spacing 0.8px, UPPERCASE

### Spacing & radii

- Phone screen horizontal padding: 16–24px
- Card interior padding: 14–18px
- Card radius: 12–14px
- Button radius: 12–14px
- Small pill/chip radius: 7–8px
- Full-width primary buttons: 16–18px vertical padding
- Section spacing: 14–22px between major blocks

### Buttons

**Primary (amber):**
```
background: --amber;
color: --ink;
box-shadow: 0 4px 0 --amber-deep, 0 8px 20px rgba(198,126,26,0.25);
font: Archivo 800 18px, letter-spacing 0.3px, UPPERCASE;
padding: 18px;
border-radius: 14px;
```

**Success (Delivered — green, same shape):**
```
background: --moss;
color: --paper;
box-shadow: 0 3px 0 --moss-deep;
```

**Secondary (Skip, Pause, Cancel):**
```
background: --card;
border: 1.5px solid --line;
color: --text-high;
font: Archivo 700 13px, UPPERCASE;
```

**Dark primary (used on Back to Routes):**
```
background: --ink;
color: --paper;
```

No hover states needed for the phone screens. The admin screens should have subtle hover (darken background ~5%) on interactive rows.

---

## Screens

### Driver App (mobile, 376px reference width)

#### 1. Route List (`/routes`)

**Purpose:** Driver opens app, sees routes assigned to them, picks one.

**Layout:**
- Sticky status bar (14px top padding, displays time + signal/battery icons)
- Header block (24px horizontal padding):
  - Logo row: 32×32 black square with rotated amber diamond inside, wordmark "ROUTE·RUNNER" (Archivo 800, 16px), date chip on right (mono 11px)
  - Greeting: "Morning, [firstName]." — 44px Archivo 800, two-line break after comma, line-height 0.95
  - Subhead: "{N} routes ready. Tap one to roll." — 15px, --text-mid
- Scrollable route list (16px horizontal padding)

**Route card:**
- `1.5px solid --line` border, radius 14, 18px padding, 10px margin-bottom
- **If in progress:** `background: --ink`, `color: --text-on-ink`, 3px amber bar at top, "● IN PROGRESS" mono label in amber
- **If not in progress:** `background: --card`, "READY" mono label in --text-low
- Route name (Archivo 700, 22px) on left
- Circular arrow button on right: 34×34, radius 17 — amber if in-progress, --ink if not
- Bottom row: 3-column grid of stats separated by 1px top border
  - Stops (e.g. "4/12" if resuming, or "12")
  - Time (e.g. "3h 24m")
  - Charge ($112) — rendered in amber if *not* in-progress to draw the eye

#### 2. Route Preview / Start (`/routes/:id`)

**Purpose:** Driver taps a route, reviews it, starts driving.

**Layout:**
- Status bar
- Top nav: back button (40×40 card-style square with chevron), "ROUTE PREVIEW" eyebrow centered, ellipsis menu on right
- Route name (Archivo 800, 30px) + subtitle ("12 stops · auto-optimized for fastest drive")
- **Estimate strip**: dark `--ink` card, radius 14, 3-column grid showing Stops / Est. Time / Charge. "Charge" in amber.
- Stop list (cream card, 1.5px border):
  - Row per stop: 11px vertical padding, 12px gap between avatar + text
  - Avatar: 28×28 rounded-square, number inside (mono 700)
    - Default: --paper-2 bg, --text-mid number
    - Delivered: --moss bg with white checkmark
    - Active (resume): --amber bg, 3px amber left-rail on the whole row
  - Stop name: 14px, weight 600 (strikethrough if delivered, opacity 0.45)
  - Address: 11.5px, --text-low
- "Delivery Order ↓ OPTIMIZED" section header above list (mono labels)

**Bottom-pinned primary action:**
- If resuming: amber banner above button ("Resuming — 4 delivered, 8 left") with pulsing amber dot
- Full-width amber button: **START ROUTE** or **RESUME ROUTE** with play-triangle icon

#### 3. Navigation (`/routes/:id/nav`)

**Purpose:** Driver is driving. Show next stop, next turn, and let them mark the current stop done.

**Layout (stacked from top):**
- Status bar (transparent over map)
- **Turn instruction card** (top, 48px from top):
  - Dark `--ink` card, radius 14, 12×14 padding
  - Left: 52×52 amber square with white turn-arrow SVG
  - Right: distance ("0.3 mi") in 24px Archivo 800 amber, then instruction ("Turn right onto Cahaba Road") in 13.5px on cream
- **Stop counter badge** (top-right, below turn card): cream 2px black-bordered chip showing "STOP / 5/12"
- **Voice toggle** (below badge): 44×44 circular button. Amber speaker icon on dark when on, muted speaker icon on cream when off.
- **Map** fills the remaining space (this is your existing Google Maps / Mapbox view)
- **Bottom sheet** (always visible, not swipeable):
  - Pinned to bottom, radius 22 top corners, `--paper` background, -4px upward shadow
  - 4px amber progress bar across the top (width = delivered/total)
  - "● HEADING TO" mono eyebrow with pulsing amber dot
  - Current stop name (22px Archivo 800) + address (13px --text-mid)
  - Chip row: amber-tinted pills for ETA ("4 min") and distance ("0.8 mi") + cream "Maps" deep-link button on right
  - **Action grid** (2fr / 1fr / 1fr): **DELIVERED** (green, primary-style) / Skip / Pause

**Key interaction:** Tapping Delivered advances to the next stop. Tapping the last stop's Delivered routes to the Complete screen. Skip also advances but increments skippedCount.

#### 4. Paused (`/routes/:id/pause`)

**Purpose:** Driver took a break. Reassure them progress is saved; show where they left off.

**Layout:**
- Entire screen `--ink` background, `--paper` text
- Status bar (dark variant)
- Header: pulsing amber dot + "PAUSED" label, then "Taking a breather." in 38px Archivo 800 (two-line break), then reassurance copy (14px, 72% paper)
- **Big progress ring** centered: 220×220, 14px stroke, amber arc on dark track, huge delivered-count number in the middle (72px Archivo 800 amber), "OF 12 DELIVERED" mono label below
- **Up-next card** below ring: `--ink-2` bg, amber stats — "UP NEXT · STOP 5" + stop name, count of remaining stops
- Two buttons pinned bottom:
  - **RESUME** (full amber, play icon)
  - **END TRIP** (transparent with --ink-3 border, small text)

#### 5. Complete (`/routes/:id/complete`)

**Purpose:** Celebrate + show profit/loss.

**Layout:**
- Status bar
- Hero: green "COMPLETE" pill tag, "Nice work, [firstName]." in 44px Archivo 800, route name below
- **3-column BigStat grid**:
  - Delivered (green top-bar) — count
  - Skipped (rust top-bar) — count
  - Total Time — "3h 0m"
- **Trip Ledger card** (`--ink` bg):
  - "TRIP LEDGER" amber eyebrow + ticket-number style ID on right (e.g. "#VE-472")
  - Giant profit number (56px Archivo 800) in amber (rust if negative) on left, "Charged $112" on right, both above a dashed divider
  - Line items (mono, right-aligned values):
    - "Driver pay · 3h 0m @ $20/hr"  $60
    - "Gas · 28 mi @ $0.18"  $5.04
    - "Cost total"  $65.04 (bold, larger)
  - **Footer hint** card inside: amber eyebrow "NEXT TIME →" + "Charge at least $81 (cost + 25% cushion)."
- Bottom-pinned **BACK TO ROUTES** dark button

---

### Admin App (~440px reference width; same visual language, different chrome)

#### Admin Top Bar (present on every admin screen)

- `--ink` bg, 3px amber bottom-border
- Logo row: 28×28 amber rounded-square + "ROUTE·RUNNER" wordmark + "ADMIN CONSOLE" mono sublabel, all on left
- "SYNCED" status chip on right: green dot + mono text in `--ink-2` pill
- Tab strip below: "UPLOAD" / "ROUTES" — active tab has amber underline and amber text

#### 1. Upload (`/admin/upload`) — three stages

**Stage A — idle:**
- H1 "New Route" + copy "Drop in a CSV or Excel — we'll geocode, optimize, and price it."
- Big dashed drop-zone card: cream bg, 2px dashed --line border, 32px padding, 54×54 dark ink square with amber upload arrow inside. Copy "Drop delivery list" + "CSV · XLSX · XLS · up to 10 MB".
- **How it works** card (dark ink, numbered 1-2-3 amber badges): Geocode → Optimize → Price
- Expected columns chip row (Company / Street / Suite / City / Zip)

**Stage B — processing:**
- Centered 120×120 progress ring (amber arc on --paper-2 track, 8px stroke)
- Percentage in middle (28px Archivo 800)
- Status text below: "Reading file…" → "Geocoding stops…" → "Optimizing route…" based on progress
- Sub-status: e.g. "6 / 12 addresses found" in mono

**Stage C — ready:**
- Green success banner: "✓ All 12 stops found and optimized."
- Route Name input (default "Vestavia Monday") — `--card` bg, 1.5px border
- **Estimate card** (`--ink` bg):
  - "TRIP ESTIMATE" amber eyebrow
  - Giant "$112 to charge" line (56px amber + "to charge" in small muted text)
  - 3-column MiniStat grid in --ink-2 sub-cards: Time / Drive / Per Stop
  - Collapsible `<details>` "▸ How we got this" revealing the breakdown (labor / gas / cushion)
- Stop preview card: first 5 stops + "+ 7 more stops" summary row
- Cancel / **SAVE ROUTE** buttons at bottom (1/2 split)

#### 2. Saved Routes (`/admin/routes`)

- H1 "Saved Routes" + total count on right
- Route card per route (`--card` bg, 1.5px border):
  - Status eyebrow: "● DRIVER RUNNING NOW" (amber pulsing) or "IDLE" (gray)
  - Route name (Archivo 700, 19px) + stats line in mono
  - Dark "EDIT" button on right
  - Secondary row: Duplicate / Export / **Delete** (outlined rust) — full-width 3-column

#### 3. Edit Route (`/admin/routes/:id/edit`)

- Back link: "← ALL ROUTES" (mono label)
- Route name headline + "12 stops · drag or use arrows to reorder"
- Stop list (cream card):
  - Per row: up/down arrow stack (22×16 each), numbered ink avatar (amber number), stop name + address, X delete button (rust stroke)
- "+ Add Stop" dashed outline button
- **Warning card** (amber-soft bg, --amber border):
  - "HEADS UP" mono eyebrow
  - "Reordering disables auto-optimization. Driver still starts from their current GPS position — but the stop sequence is now locked to your order."
- Cancel / **SAVE CHANGES** buttons at bottom

---

## Interactions & Behavior

### Driver flow state machine

```
list ──tap route──▶ start ──Start Route──▶ nav
                                            │
                                            ├─Delivered──▶ (stopIdx++, delivered++) ──last stop?──▶ complete
                                            │                                                    │
                                            │                                                    └─no──▶ nav
                                            ├─Skip──▶ (stopIdx++, skipped++)
                                            └─Pause──▶ paused ──Resume──▶ nav
                                                              └─End Trip──▶ list
complete ──Back to Routes──▶ list
```

Resume state (when a route is already in progress) is detected on the list screen and shown as a dark card. The Start screen shows "RESUME ROUTE" instead of "START ROUTE" and a banner with counts.

### Animations

- **Pulsing dots** (in-progress indicators, paused, "heading to"): 1.4–1.6s ease-in-out, opacity 1 → 0.35 → 1. Use a keyframe:
  ```
  @keyframes rr-pulse { 0%,100% {opacity:1;} 50% {opacity:0.35;} }
  ```
- **Upload progress ring**: stroke-dashoffset transitions at 0.2s.
- **No elaborate page transitions** — rely on simple fade/translate if the existing app has them. The design doesn't require anything custom.

### Voice toggle (nav screen)

Persists to user preferences (Firestore user doc or localStorage). Controls whether turn-by-turn audio plays.

### Progress persistence

When a driver starts or advances through a route, write `{ currentStopIndex, deliveredCount, skippedCount, updatedAt }` to the route's Firestore doc. Hydrate on route list load to detect "in progress" state.

---

## State Management

Per the prototype's `DriverApp` context, the minimum shape is:

```ts
type DriverState = {
  routeKey: string | null;         // which route is selected
  stops: Stop[];                   // ordered, with per-stop {delivered, skipped} flags
  stopIdx: number;                 // current stop (0-based)
  delivered: number;
  skipped: number;
  voiceOn: boolean;
};
```

Hook into your existing route/stop data model. The prototype's `MOCK_ROUTES` / `MOCK_PROGRESS` are only illustrative — do not port them.

---

## Copywriting (keep verbatim)

These strings are part of the design language. Don't paraphrase:

- List: "{Firstname}, rise and shine." / "Morning, {Firstname}." (use the one that matches current time)
- List subhead: "{N} routes ready. Tap one to roll."
- List empty state (if no routes): "Nothing on the board yet. Ask admin to load one."
- Nav eyebrow: "HEADING TO"
- Paused headline: "Taking a breather."
- Paused reassurance: "Your progress is saved. Close the app, come back whenever. The route will be waiting."
- Complete headline: "Nice work, {Firstname}."
- Ledger hint: "Charge at least $[cost × 1.25] (cost + 25% cushion)."
- Edit-route warning: "Reordering disables auto-optimization. Driver still starts from their current GPS position — but the stop sequence is now locked to your order."
- Admin upload card: "Drop delivery list" / "CSV · XLSX · XLS · up to 10 MB"
- Admin how-it-works steps: "Geocode each address" / "Optimize the order" / "Price the trip"

---

## Assets

- **Fonts:** Archivo, Inter Tight, JetBrains Mono — all free on Google Fonts. See Typography section for import URL.
- **Icons:** All icons in the prototype are inline SVGs (stroke-width 2–2.6, round caps). If the codebase uses Lucide or Feather, map as follows:
  - turn-right arrow → custom (see driver-screens.jsx nav screen); or Lucide `corner-up-right`
  - checkmark → Lucide `check`
  - location pin → Lucide `map-pin`
  - clock → Lucide `clock`
  - upload arrow → Lucide `upload`
  - play triangle → Lucide `play` (filled)
  - speaker on/off → Lucide `volume-2` / `volume-x`
- **Logo mark:** 32×32 rounded-square (radius 7) black background with a rotated 10×10 amber diamond inside. Pure CSS — see driver-screens.jsx header.
- **No image assets required.**

---

## Files in this bundle

Everything in `prototype/` is reference material. Open `Route Runner.html` in a browser to see the full interactive design (pan/zoom canvas with all 9 screens side-by-side). Tap into the "Interactive Flow" artboard on the driver row to click through the real state machine.

- `prototype/Route Runner.html` — entry point, wires together all screens on a pan/zoom design canvas
- `prototype/theme.jsx` — the `RR` design-token object + mock data. Reference this for exact hex values, font stacks, and the spring `@keyframes rr-pulse`.
- `prototype/driver-screens.jsx` — all 5 driver screens as React components. Useful for exact markup structure, spacing, and copy.
- `prototype/admin-screens.jsx` — all admin screens (Upload, Saved Routes, Edit Route).
- `prototype/design-canvas.jsx` — the Figma-ish pan/zoom wrapper used to display the prototypes. Ignore for implementation; it's purely the presentation shell.

---

## Out of scope for this handoff

These are explicitly *not* part of the redesign — leave existing functionality alone unless the user requests otherwise:

- Authentication & login screens
- Firebase schema changes
- Geocoding / TSP implementation
- Map library choice
- Real signature capture or photo-proof-of-delivery (the prototype doesn't include these)
- Offline handling (the prototype shows "Paused" reassurance copy but doesn't implement offline sync)
- Push notifications
