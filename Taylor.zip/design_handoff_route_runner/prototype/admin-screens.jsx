// Admin screens — Route Runner
// Upload, estimate review, saved routes management, edit route

function AdminApp({ initialScreen = 'upload' }) {
  const [screen, setScreen] = React.useState(initialScreen);
  const [routeKey, setRouteKey] = React.useState(null);
  const [uploadStage, setUploadStage] = React.useState('idle'); // idle | processing | ready

  return (
    <div className="rr" style={{ width: '100%', height: '100%', background: RR.paper, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
      <AdminTopBar screen={screen} setScreen={setScreen} />
      <div style={{ flex: 1, overflowY: 'auto' }}>
        {screen === 'upload' && <AdminUpload stage={uploadStage} setStage={setUploadStage} onDone={() => setScreen('routes')} />}
        {screen === 'routes' && <AdminRoutes onEdit={(k) => { setRouteKey(k); setScreen('edit'); }} />}
        {screen === 'edit' && <AdminEdit routeKey={routeKey} onBack={() => setScreen('routes')} />}
      </div>
    </div>
  );
}

function AdminTopBar({ screen, setScreen }) {
  const tabs = [
    { id: 'upload', label: 'Upload' },
    { id: 'routes', label: 'Routes' },
  ];
  return (
    <div style={{ background: RR.ink, color: RR.textOnInk, padding: '14px 20px 0', borderBottom: `3px solid ${RR.amber}` }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 28, height: 28, borderRadius: 6, background: RR.amber, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <div style={{ width: 9, height: 9, background: RR.ink, borderRadius: 1, transform: 'rotate(45deg)' }} />
          </div>
          <div>
            <div style={{ fontFamily: RR.display, fontSize: 15, fontWeight: 800, letterSpacing: -0.2, color: RR.textOnInk }}>ROUTE<span style={{ color: RR.amber }}>·</span>RUNNER</div>
            <div style={{ fontFamily: RR.mono, fontSize: 9.5, color: RR.textOnInk3, letterSpacing: 1, textTransform: 'uppercase', fontWeight: 600 }}>Admin Console</div>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 10px', background: RR.ink2, borderRadius: 20, border: `1px solid ${RR.ink3}` }}>
          <div style={{ width: 7, height: 7, borderRadius: 4, background: RR.moss }} />
          <span style={{ fontFamily: RR.mono, fontSize: 10, color: RR.textOnInk2, fontWeight: 600 }}>SYNCED</span>
        </div>
      </div>
      <div style={{ display: 'flex', gap: 0 }}>
        {tabs.map(t => (
          <button key={t.id} onClick={() => setScreen(t.id === 'routes' && screen === 'edit' ? 'routes' : t.id)}
            style={{ padding: '10px 16px', fontFamily: RR.display, fontSize: 13, fontWeight: 700, letterSpacing: 0.3, textTransform: 'uppercase',
              color: (screen === t.id || (t.id === 'routes' && screen === 'edit')) ? RR.amber : RR.textOnInk2,
              borderBottom: `2px solid ${(screen === t.id || (t.id === 'routes' && screen === 'edit')) ? RR.amber : 'transparent'}`,
              marginBottom: -3 }}>{t.label}</button>
        ))}
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════
// UPLOAD
// ══════════════════════════════════════════════════════════════════════
function AdminUpload({ stage, setStage, onDone }) {
  const [progress, setProgress] = React.useState(0);
  const [routeName, setRouteName] = React.useState('Vestavia Monday');

  const doUpload = () => {
    setStage('processing');
    setProgress(0);
    let p = 0;
    const iv = setInterval(() => {
      p += 8 + Math.random() * 14;
      if (p >= 100) { p = 100; clearInterval(iv); setTimeout(() => setStage('ready'), 300); }
      setProgress(p);
    }, 160);
  };

  if (stage === 'idle') {
    return (
      <div style={{ padding: '20px 16px 40px' }}>
        <div style={{ fontFamily: RR.display, fontSize: 28, fontWeight: 800, letterSpacing: -0.4, color: RR.textHigh, lineHeight: 1 }}>New Route</div>
        <div style={{ fontSize: 13.5, color: RR.textMid, marginTop: 6, marginBottom: 18 }}>Drop in a CSV or Excel — we'll geocode, optimize, and price it.</div>

        <button onClick={doUpload} style={{ display: 'block', width: '100%', padding: '32px 20px', background: '#FFFAEE', border: `2px dashed ${RR.line}`, borderRadius: 16, textAlign: 'center' }}>
          <div style={{ width: 54, height: 54, borderRadius: 14, background: RR.ink, margin: '0 auto 12px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke={RR.amber} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3v12M6 9l6-6 6 6M4 21h16"/></svg>
          </div>
          <div style={{ fontFamily: RR.display, fontSize: 17, fontWeight: 700, color: RR.textHigh, letterSpacing: -0.2 }}>Drop delivery list</div>
          <div style={{ fontSize: 12, color: RR.textLow, marginTop: 3 }}>CSV · XLSX · XLS · up to 10 MB</div>
        </button>

        <div style={{ marginTop: 22, padding: '14px 16px', background: RR.ink, borderRadius: 12, color: RR.textOnInk }}>
          <div style={{ fontFamily: RR.mono, fontSize: 10, color: RR.amber, fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase', marginBottom: 10 }}>How it works</div>
          <Step n={1} label="Geocode each address" desc="Street + zip first, fallbacks if needed" />
          <Step n={2} label="Optimize the order" desc="Nearest-neighbor TSP across all stops" />
          <Step n={3} label="Price the trip" desc="Driver pay + gas + 25% cushion" />
        </div>

        <div style={{ marginTop: 16, padding: '12px 14px', background: '#FFFAEE', border: `1px solid ${RR.line}`, borderRadius: 10 }}>
          <div style={{ fontFamily: RR.mono, fontSize: 10, color: RR.textLow, fontWeight: 600, letterSpacing: 0.8, textTransform: 'uppercase' }}>Expected columns</div>
          <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap', marginTop: 8 }}>
            {['Company', 'Street', 'Suite', 'City', 'Zip'].map(c => (
              <span key={c} style={{ padding: '4px 8px', background: RR.paper2, fontFamily: RR.mono, fontSize: 11, fontWeight: 600, color: RR.textHigh, borderRadius: 4 }}>{c}</span>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (stage === 'processing') {
    return (
      <div style={{ padding: '40px 20px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: 400 }}>
        <div style={{ position: 'relative', width: 120, height: 120, marginBottom: 22 }}>
          <svg width="120" height="120" viewBox="0 0 120 120" style={{ transform: 'rotate(-90deg)' }}>
            <circle cx="60" cy="60" r="50" fill="none" stroke={RR.paper2} strokeWidth="8"/>
            <circle cx="60" cy="60" r="50" fill="none" stroke={RR.amber} strokeWidth="8" strokeLinecap="round"
              strokeDasharray={2 * Math.PI * 50} strokeDashoffset={2 * Math.PI * 50 * (1 - progress/100)} style={{ transition: 'stroke-dashoffset 0.2s' }} />
          </svg>
          <div className="num display" style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, fontWeight: 800, color: RR.textHigh }}>
            {Math.round(progress)}<span style={{ fontSize: 16, color: RR.textLow }}>%</span>
          </div>
        </div>
        <div style={{ fontFamily: RR.display, fontSize: 20, fontWeight: 700, color: RR.textHigh, letterSpacing: -0.3 }}>
          {progress < 40 ? 'Reading file…' : progress < 80 ? 'Geocoding stops…' : 'Optimizing route…'}
        </div>
        <div style={{ fontSize: 13, color: RR.textMid, marginTop: 4, fontFamily: RR.mono }}>
          {progress < 40 ? '12 rows detected' : progress < 80 ? `${Math.round(progress/8)} / 12 addresses found` : 'Running nearest-neighbor solver'}
        </div>
      </div>
    );
  }

  // ready
  const stops = MOCK_ROUTES['Vestavia Monday'].stops;
  const est = MOCK_ROUTES['Vestavia Monday'].estimate;
  return (
    <div style={{ padding: '16px 16px 120px' }}>
      <div style={{ padding: '10px 14px', background: RR.moss, color: RR.paper, borderRadius: 10, marginBottom: 14, fontSize: 13, display: 'flex', alignItems: 'center', gap: 8 }}>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={RR.paper} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
        <span style={{ fontWeight: 600 }}>All 12 stops found and optimized.</span>
      </div>

      {/* Name input */}
      <div style={{ marginBottom: 14 }}>
        <label style={{ display: 'block', fontFamily: RR.mono, fontSize: 10, fontWeight: 700, color: RR.textLow, letterSpacing: 0.8, textTransform: 'uppercase', marginBottom: 6 }}>Route Name</label>
        <input value={routeName} onChange={e => setRouteName(e.target.value)}
          style={{ width: '100%', padding: '12px 14px', background: '#FFFAEE', border: `1.5px solid ${RR.line}`, borderRadius: 10, fontFamily: RR.body, fontSize: 15, color: RR.textHigh, outline: 'none' }} />
      </div>

      {/* Estimate card */}
      <div style={{ background: RR.ink, color: RR.textOnInk, borderRadius: 16, padding: '18px', marginBottom: 14 }}>
        <div style={{ fontFamily: RR.mono, fontSize: 10, color: RR.amber, fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase', marginBottom: 14 }}>Trip Estimate</div>

        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 4, marginBottom: 14, paddingBottom: 14, borderBottom: `1px dashed ${RR.ink3}` }}>
          <span className="num display" style={{ fontSize: 56, fontWeight: 800, color: RR.amber, lineHeight: 0.9, letterSpacing: -0.04 }}>${Math.round(est.suggestedPrice)}</span>
          <span style={{ fontSize: 13, color: RR.textOnInk3, paddingBottom: 8, marginLeft: 6 }}>to charge</span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
          <MiniStat label="Time" value={fmtHours(est.totalHours)} />
          <MiniStat label="Drive" value={`${est.totalMiles.toFixed(0)}mi`} />
          <MiniStat label="Per Stop" value={`$${est.perStop.toFixed(2)}`} />
        </div>

        <details style={{ marginTop: 14 }}>
          <summary style={{ cursor: 'pointer', fontFamily: RR.mono, fontSize: 11, color: RR.textOnInk2, letterSpacing: 0.5, listStyle: 'none' }}>
            ▸ How we got this
          </summary>
          <div style={{ marginTop: 10, padding: '10px 12px', background: RR.ink2, borderRadius: 8, fontSize: 12, color: RR.textOnInk2, lineHeight: 1.7 }}>
            <div>Driver pay · {fmtHours(est.totalHours)} @ $20/hr: <strong style={{ color: RR.textOnInk, fontFamily: RR.mono }}>${est.laborCost.toFixed(2)}</strong></div>
            <div>Gas · {est.totalMiles.toFixed(0)}mi @ $0.18: <strong style={{ color: RR.textOnInk, fontFamily: RR.mono }}>${est.gasCost.toFixed(2)}</strong></div>
            <div>25% cushion: <strong style={{ color: RR.textOnInk, fontFamily: RR.mono }}>${est.cushion.toFixed(2)}</strong></div>
          </div>
        </details>
      </div>

      {/* Stop preview */}
      <div style={{ background: '#FFFAEE', border: `1.5px solid ${RR.line}`, borderRadius: 14, overflow: 'hidden', marginBottom: 14 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 14px', borderBottom: `1px solid ${RR.paper2}` }}>
          <span style={{ fontFamily: RR.mono, fontSize: 10, fontWeight: 700, color: RR.textMid, letterSpacing: 0.8, textTransform: 'uppercase' }}>{stops.length} Stops · Optimized</span>
          <span style={{ fontFamily: RR.mono, fontSize: 10, color: RR.amberDeep, fontWeight: 600 }}>TSP</span>
        </div>
        {stops.slice(0, 5).map((s, i) => (
          <div key={i} style={{ display: 'flex', padding: '10px 14px', gap: 10, alignItems: 'center', borderBottom: i < 4 ? `1px solid ${RR.paper2}` : 'none' }}>
            <div className="num" style={{ width: 22, height: 22, borderRadius: 5, background: RR.paper2, color: RR.textMid, fontFamily: RR.mono, fontSize: 11, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{i+1}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 13.5, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{s.name}</div>
              <div style={{ fontSize: 11, color: RR.textLow, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{s.address}</div>
            </div>
          </div>
        ))}
        <div style={{ padding: '10px 14px', textAlign: 'center', fontSize: 12, color: RR.textLow, fontFamily: RR.mono }}>+ {stops.length - 5} more stops</div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 8 }}>
        <button onClick={() => setStage('idle')} style={{ padding: '16px', background: '#FFFAEE', border: `1.5px solid ${RR.line}`, borderRadius: 12, fontFamily: RR.display, fontSize: 13, fontWeight: 700, color: RR.textMid, letterSpacing: 0.3, textTransform: 'uppercase' }}>Cancel</button>
        <button onClick={onDone} style={{ padding: '16px', background: RR.amber, color: RR.ink, borderRadius: 12, fontFamily: RR.display, fontSize: 15, fontWeight: 800, letterSpacing: 0.3, textTransform: 'uppercase', boxShadow: `0 3px 0 ${RR.amberDeep}` }}>Save Route</button>
      </div>
    </div>
  );
}

function MiniStat({ label, value }) {
  return (
    <div style={{ padding: '10px 12px', background: RR.ink2, border: `1px solid ${RR.ink3}`, borderRadius: 8 }}>
      <div style={{ fontFamily: RR.mono, fontSize: 9, fontWeight: 600, color: RR.textOnInk3, letterSpacing: 0.7, textTransform: 'uppercase' }}>{label}</div>
      <div className="num" style={{ fontFamily: RR.display, fontSize: 18, fontWeight: 800, color: RR.textOnInk, marginTop: 2, letterSpacing: -0.3 }}>{value}</div>
    </div>
  );
}

function Step({ n, label, desc }) {
  return (
    <div style={{ display: 'flex', gap: 11, padding: '6px 0' }}>
      <div className="num" style={{ width: 22, height: 22, borderRadius: 5, background: RR.ink2, border: `1px solid ${RR.ink3}`, color: RR.amber, fontFamily: RR.mono, fontSize: 11, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{n}</div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 13.5, fontWeight: 600, color: RR.textOnInk }}>{label}</div>
        <div style={{ fontSize: 11, color: RR.textOnInk3 }}>{desc}</div>
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════
// ROUTES LIST (admin)
// ══════════════════════════════════════════════════════════════════════
function AdminRoutes({ onEdit }) {
  const keys = Object.keys(MOCK_ROUTES).sort((a,b) => MOCK_ROUTES[b].savedAt - MOCK_ROUTES[a].savedAt);
  return (
    <div style={{ padding: '16px 16px 40px' }}>
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 14 }}>
        <div style={{ fontFamily: RR.display, fontSize: 26, fontWeight: 800, letterSpacing: -0.4, color: RR.textHigh }}>Saved Routes</div>
        <span className="num" style={{ fontFamily: RR.mono, fontSize: 13, color: RR.textLow, fontWeight: 600 }}>{keys.length} total</span>
      </div>

      {keys.map(k => {
        const r = MOCK_ROUTES[k];
        const isLive = MOCK_PROGRESS[k] != null;
        return (
          <div key={k} style={{ padding: '16px', background: '#FFFAEE', border: `1.5px solid ${RR.line}`, borderRadius: 12, marginBottom: 10 }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 10 }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 2 }}>
                  {isLive && <div style={{ width: 6, height: 6, borderRadius: 3, background: RR.amber, animation: 'rr-pulse 1.6s infinite' }} />}
                  <span style={{ fontFamily: RR.mono, fontSize: 9.5, color: isLive ? RR.amberDeep : RR.textLow, fontWeight: 700, letterSpacing: 0.8, textTransform: 'uppercase' }}>{isLive ? 'Driver Running Now' : 'Idle'}</span>
                </div>
                <div style={{ fontFamily: RR.display, fontSize: 19, fontWeight: 700, color: RR.textHigh, letterSpacing: -0.3 }}>{r.name}</div>
                <div style={{ fontSize: 12, color: RR.textLow, marginTop: 2, fontFamily: RR.mono }}>{r.stopCount} stops · {fmtHours(r.estimate.totalHours)} · ${Math.round(r.estimate.suggestedPrice)}</div>
              </div>
              <button onClick={() => onEdit(k)} style={{ padding: '8px 14px', background: RR.ink, color: RR.paper, borderRadius: 8, fontFamily: RR.display, fontSize: 12, fontWeight: 700, letterSpacing: 0.4, textTransform: 'uppercase', flexShrink: 0 }}>Edit</button>
            </div>
            <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
              <button style={{ flex: 1, padding: '8px', background: 'transparent', border: `1px solid ${RR.line}`, borderRadius: 7, fontSize: 11.5, fontWeight: 600, color: RR.textMid, fontFamily: RR.mono, letterSpacing: 0.4, textTransform: 'uppercase' }}>Duplicate</button>
              <button style={{ flex: 1, padding: '8px', background: 'transparent', border: `1px solid ${RR.line}`, borderRadius: 7, fontSize: 11.5, fontWeight: 600, color: RR.textMid, fontFamily: RR.mono, letterSpacing: 0.4, textTransform: 'uppercase' }}>Export</button>
              <button style={{ flex: 1, padding: '8px', background: 'transparent', border: `1px solid ${RR.rust}`, borderRadius: 7, fontSize: 11.5, fontWeight: 600, color: RR.rust, fontFamily: RR.mono, letterSpacing: 0.4, textTransform: 'uppercase' }}>Delete</button>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════
// EDIT ROUTE
// ══════════════════════════════════════════════════════════════════════
function AdminEdit({ routeKey, onBack }) {
  const r = MOCK_ROUTES[routeKey]; if (!r) return null;
  const [stops, setStops] = React.useState(r.stops);

  const move = (i, dir) => {
    setStops(prev => {
      const ni = i + dir;
      if (ni < 0 || ni >= prev.length) return prev;
      const copy = [...prev];
      [copy[i], copy[ni]] = [copy[ni], copy[i]];
      return copy;
    });
  };

  const remove = (i) => setStops(prev => prev.filter((_, idx) => idx !== i));

  return (
    <div style={{ padding: '14px 16px 120px' }}>
      <button onClick={onBack} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: RR.textMid, fontFamily: RR.mono, letterSpacing: 0.4, textTransform: 'uppercase', fontWeight: 600, marginBottom: 14 }}>
        <svg width="10" height="10" viewBox="0 0 10 10" fill="none"><path d="M6 2L3 5l3 3" stroke={RR.textMid} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
        All Routes
      </button>

      <div style={{ fontFamily: RR.display, fontSize: 26, fontWeight: 800, letterSpacing: -0.4, color: RR.textHigh }}>{r.name}</div>
      <div style={{ fontSize: 13, color: RR.textMid, marginTop: 3, marginBottom: 14 }}>{stops.length} stops · drag or use arrows to reorder</div>

      <div style={{ background: '#FFFAEE', border: `1.5px solid ${RR.line}`, borderRadius: 12, overflow: 'hidden' }}>
        {stops.map((s, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', padding: '10px 8px 10px 10px', gap: 8, borderBottom: i < stops.length - 1 ? `1px solid ${RR.paper2}` : 'none' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              <button onClick={() => move(i, -1)} disabled={i === 0} style={{ width: 22, height: 16, borderRadius: 4, background: RR.paper2, display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: i === 0 ? 0.3 : 1 }}>
                <svg width="9" height="6" viewBox="0 0 9 6" fill="none"><path d="M1 5l3.5-3.5L8 5" stroke={RR.textMid} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"/></svg>
              </button>
              <button onClick={() => move(i, 1)} disabled={i === stops.length - 1} style={{ width: 22, height: 16, borderRadius: 4, background: RR.paper2, display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: i === stops.length - 1 ? 0.3 : 1 }}>
                <svg width="9" height="6" viewBox="0 0 9 6" fill="none"><path d="M1 1l3.5 3.5L8 1" stroke={RR.textMid} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"/></svg>
              </button>
            </div>
            <div className="num" style={{ width: 26, height: 26, borderRadius: 6, background: RR.ink, color: RR.amber, fontFamily: RR.mono, fontSize: 12, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{i + 1}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 13.5, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{s.name}</div>
              <div style={{ fontSize: 11, color: RR.textLow, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{s.address}</div>
            </div>
            <button onClick={() => remove(i)} style={{ width: 28, height: 28, borderRadius: 6, background: 'transparent' }}>
              <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2 2l8 8M10 2l-8 8" stroke={RR.rust} strokeWidth="2" strokeLinecap="round"/></svg>
            </button>
          </div>
        ))}
      </div>

      <button style={{ marginTop: 10, width: '100%', padding: '14px', background: 'transparent', border: `1.5px dashed ${RR.line}`, borderRadius: 10, fontFamily: RR.display, fontSize: 13, fontWeight: 700, color: RR.textMid, letterSpacing: 0.3, textTransform: 'uppercase', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M7 2v10M2 7h10" stroke={RR.textMid} strokeWidth="2" strokeLinecap="round"/></svg>
        Add Stop
      </button>

      <div style={{ marginTop: 14, padding: '14px', background: RR.amberSoft, borderRadius: 10, border: `1px solid ${RR.amber}` }}>
        <div style={{ fontFamily: RR.mono, fontSize: 10, fontWeight: 700, color: RR.amberDeep, letterSpacing: 0.8, textTransform: 'uppercase', marginBottom: 4 }}>Heads up</div>
        <div style={{ fontSize: 12.5, color: RR.textHigh, lineHeight: 1.4 }}>Reordering disables auto-optimization. Driver still starts from their current GPS position — but the stop sequence is now locked to your order.</div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 8, marginTop: 14 }}>
        <button onClick={onBack} style={{ padding: '14px', background: '#FFFAEE', border: `1.5px solid ${RR.line}`, borderRadius: 12, fontFamily: RR.display, fontSize: 13, fontWeight: 700, color: RR.textMid, letterSpacing: 0.3, textTransform: 'uppercase' }}>Cancel</button>
        <button onClick={onBack} style={{ padding: '14px', background: RR.amber, color: RR.ink, borderRadius: 12, fontFamily: RR.display, fontSize: 14, fontWeight: 800, letterSpacing: 0.3, textTransform: 'uppercase', boxShadow: `0 3px 0 ${RR.amberDeep}` }}>Save Changes</button>
      </div>
    </div>
  );
}

Object.assign(window, { AdminApp });
