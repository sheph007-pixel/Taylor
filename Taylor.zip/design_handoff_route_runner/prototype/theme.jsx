// Route Runner — design tokens
// Rugged-utilitarian. Warm ink background, cream paper surface, road-sign amber accent.

const RR = {
  // Surfaces
  ink:        '#16130F',   // near-black, warm
  ink2:       '#1F1B16',   // elevated dark
  ink3:       '#2A241C',   // borders in dark
  paper:      '#F5EFE3',   // cream, off-white
  paper2:     '#EBE3D2',   // subtle divider
  paper3:     '#DDD2BC',   // muted text on paper
  line:       '#CFC3A8',   // hairlines on paper

  // Accents
  amber:      '#E8A838',   // primary — road-sign yellow-orange
  amberDeep:  '#C67E1A',   // pressed / deep
  amberSoft:  '#FBE9C0',   // tint background
  rust:       '#B4522A',   // alert / skipped
  moss:       '#4E6B3A',   // success / delivered
  mossDeep:   '#36502A',

  // Text
  textHigh:   '#16130F',   // on paper
  textMid:    '#5C5245',
  textLow:    '#847761',
  textOnInk:  '#F5EFE3',
  textOnInk2: 'rgba(245,239,227,0.72)',
  textOnInk3: 'rgba(245,239,227,0.45)',

  // Semantic
  bg:         '#F5EFE3',

  // Type
  display:    '"Archivo", "Archivo Narrow", -apple-system, system-ui, sans-serif',
  body:       '"Inter Tight", -apple-system, system-ui, sans-serif',
  mono:       '"JetBrains Mono", ui-monospace, "SF Mono", Menlo, monospace',
};

// Inject fonts + global reset once
if (typeof document !== 'undefined' && !document.getElementById('rr-fonts')) {
  const link = document.createElement('link');
  link.id = 'rr-fonts';
  link.rel = 'stylesheet';
  link.href = 'https://fonts.googleapis.com/css2?family=Archivo:wght@500;600;700;800;900&family=Inter+Tight:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap';
  document.head.appendChild(link);

  const s = document.createElement('style');
  s.id = 'rr-reset';
  s.textContent = `
    .rr *, .rr *::before, .rr *::after { box-sizing: border-box; }
    .rr { font-family: ${RR.body}; color: ${RR.textHigh}; -webkit-font-smoothing: antialiased; font-feature-settings: 'ss01','cv11'; }
    .rr button { font-family: inherit; border: none; background: none; cursor: pointer; color: inherit; padding: 0; }
    .rr .num { font-family: ${RR.mono}; font-variant-numeric: tabular-nums; }
    .rr .display { font-family: ${RR.display}; letter-spacing: -0.01em; }
    .rr ::-webkit-scrollbar { display: none; }
    @keyframes rr-pulse { 0%,100% { opacity: 1; } 50% { opacity: 0.35; } }
    @keyframes rr-spin { to { transform: rotate(360deg); } }
    @keyframes rr-slide-up { from { transform: translateY(8px); opacity: 0; } to { transform: none; opacity: 1; } }
  `;
  document.head.appendChild(s);
}

// ── Mock data — realistic Birmingham/Vestavia magazine route ──────────────
const MOCK_ROUTES = {
  'Vestavia Monday': {
    name: 'Vestavia Monday',
    savedAt: Date.now() - 1000 * 60 * 60 * 18,
    stopCount: 12,
    estimate: { totalMiles: 28, totalHours: 3.4, drivingHours: 1.1, deliveryHours: 1.0, suggestedPrice: 112, perStop: 9.33, laborCost: 68, gasCost: 5.04, cushion: 22, stopCount: 12 },
    stops: [
      { name: 'Bromberg & Co. Jewelers',     address: '2800 Cahaba Rd, Mountain Brook, AL 35223', lat: 33.495, lng: -86.753 },
      { name: 'Little Hardware',             address: '2703 Culver Rd, Birmingham, AL 35223',     lat: 33.499, lng: -86.757 },
      { name: 'Saw\'s Soul Kitchen',         address: '215 41st St S, Birmingham, AL 35222',      lat: 33.523, lng: -86.769 },
      { name: 'Crestline Pharmacy',          address: '61 Church St, Mountain Brook, AL 35213',    lat: 33.500, lng: -86.752 },
      { name: 'Piggly Wiggly River Run',     address: '3825 River Run Dr, Birmingham, AL 35243',   lat: 33.458, lng: -86.720 },
      { name: 'The Pants Store Vestavia',    address: '733 Montgomery Hwy, Vestavia, AL 35216',    lat: 33.449, lng: -86.788 },
      { name: 'Golden Rule BBQ Hwy 280',     address: '1571 Montgomery Hwy, Hoover, AL 35216',     lat: 33.430, lng: -86.791 },
      { name: 'Homewood Gourmet',            address: '2921 18th St S, Homewood, AL 35209',        lat: 33.471, lng: -86.798 },
      { name: 'O\'Henry\'s Coffees',         address: '2831 18th St S, Homewood, AL 35209',        lat: 33.472, lng: -86.798 },
      { name: 'Continental Bakery',          address: '1909 Cahaba Rd, Mountain Brook, AL 35223',  lat: 33.497, lng: -86.762 },
      { name: 'Western Supermarkets',        address: '2nd Ave S, Mountain Brook, AL 35213',       lat: 33.502, lng: -86.753 },
      { name: 'V. Richards Market',          address: '3916 Clairmont Ave S, Birmingham, AL 35222',lat: 33.528, lng: -86.763 },
    ],
  },
  'Downtown Tuesday': {
    name: 'Downtown Tuesday',
    savedAt: Date.now() - 1000 * 60 * 60 * 30,
    stopCount: 8,
    estimate: { totalMiles: 14, totalHours: 2.1, drivingHours: 0.6, deliveryHours: 0.67, suggestedPrice: 74, perStop: 9.25, laborCost: 42, gasCost: 2.52, cushion: 15, stopCount: 8 },
    stops: [
      { name: 'Bottega Cafe',         address: '2240 Highland Ave S, Birmingham, AL 35205',      lat: 33.504, lng: -86.792 },
      { name: 'The Essential',        address: '2311 2nd Ave N, Birmingham, AL 35203',           lat: 33.518, lng: -86.807 },
      { name: 'Pepper Place Market',  address: '2829 2nd Ave S, Birmingham, AL 35233',           lat: 33.511, lng: -86.788 },
      { name: 'Railroad Park Cafe',   address: '1600 1st Ave S, Birmingham, AL 35233',           lat: 33.511, lng: -86.813 },
      { name: 'Rogue Tavern',         address: '2312 2nd Ave N, Birmingham, AL 35203',           lat: 33.518, lng: -86.807 },
      { name: 'Hill Florist',         address: '2008 Cahaba Rd, Birmingham, AL 35223',           lat: 33.496, lng: -86.762 },
      { name: 'Church Street Coffee', address: '81 Church St, Mountain Brook, AL 35213',          lat: 33.500, lng: -86.751 },
      { name: 'Mr. Chen\'s',          address: '3054 Independence Dr, Homewood, AL 35209',       lat: 33.476, lng: -86.800 },
    ],
  },
  'Hoover Thursday': {
    name: 'Hoover Thursday',
    savedAt: Date.now() - 1000 * 60 * 60 * 60,
    stopCount: 15,
    estimate: { totalMiles: 41, totalHours: 4.8, drivingHours: 1.6, deliveryHours: 1.25, suggestedPrice: 156, perStop: 10.40, laborCost: 96, gasCost: 7.38, cushion: 31, stopCount: 15 },
    stops: Array.from({ length: 15 }, (_, i) => ({
      name: ['Patton Creek Market','Stadium Trace Pharmacy','Ross Bridge Gallery','Riverchase Florist','Greystone Coffee','Inverness Wine','Valleydale Books','Lee Branch Outfitters','The Narrows Cafe','Tattersall Market','Brook Highland Salon','Highland Lakes Deli','Trussville Bakery','Meadow Brook Grille','Oak Mountain Pharmacy'][i],
      address: `${100 + i * 37} Hwy ${i+280}, Hoover, AL 35244`,
      lat: 33.40 + i * 0.004, lng: -86.82 - i * 0.003,
    })),
  },
};

// Saved driver progress — simulates a route mid-trip
const MOCK_PROGRESS = {
  'Vestavia Monday': { currentStopIndex: 4, deliveredCount: 4, skippedCount: 0 },
};

Object.assign(window, { RR, MOCK_ROUTES, MOCK_PROGRESS });
