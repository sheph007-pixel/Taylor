// Driver screens — Route Runner
// 5 screens: list, start, nav, paused, complete
// Interactive via useState inside each DriverApp instance.

function DriverApp({ initialScreen = 'list', initialRoute = null, initialStopIdx = 0 }) {
  const [screen, setScreen] = React.useState(initialScreen);
  const [routeKey, setRouteKey] = React.useState(initialRoute);
  const [stopIdx, setStopIdx] = React.useState(initialStopIdx);
  const [stops, setStops] = React.useState(() => routeKey ? MOCK_ROUTES[routeKey].stops.map(s => ({...s})) : []);
  const [delivered, setDelivered] = React.useState(0);
  const [skipped, setSkipped] = React.useState(0);
  const [voiceOn, setVoiceOn] = React.useState(true);

  const route = routeKey ? MOCK_ROUTES[routeKey] : null;

  const openRoute = (key) => {
    setRouteKey(key);
    const r = MOCK_ROUTES[key];
    const saved = MOCK_PROGRESS[key];
    setStops(r.stops.map(s => ({...s})));
    if (saved) {
      setStopIdx(saved.currentStopIndex);
      setDelivered(saved.deliveredCount);
      setSkipped(saved.skippedCount || 0);
    } else {
      setStopIdx(0); setDelivered(0); setSkipped(0);
    }
    setScreen('start');
  };

  const startRoute = () => setScreen('nav');
  const markDelivered = () => {
    setStops(s => { const copy = [...s]; if (copy[stopIdx]) copy[stopIdx] = {...copy[stopIdx], delivered: true}; return copy; });
    setDelivered(d => d + 1);
    if (stopIdx + 1 >= stops.length) setScreen('complete');
    else setStopIdx(i => i + 1);
  };
  const skip = () => {
    setStops(s => { const copy = [...s]; if (copy[stopIdx]) copy[stopIdx] = {...copy[stopIdx], skipped: true}; return copy; });
    setSkipped(n => n + 1);
    if (stopIdx + 1 >= stops.length) setScreen('complete');
    else setStopIdx(i => i + 1);
  };
  const pause = () => setScreen('paused');
  const resume = () => setScreen('nav');
  const endTrip = () => setScreen('list');
  const newTrip = () => { setScreen('list'); setRouteKey(null); setStopIdx(0); setDelivered(0); setSkipped(0); };

  const ctx = { screen, setScreen, route, routeKey, stops, stopIdx, delivered, skipped, voiceOn, setVoiceOn,
    openRoute, startRoute, markDelivered, skip, pause, resume, endTrip, newTrip };

  return (
    <div className="rr" style={{ width: '100%', height: '100%', background: RR.paper, overflow: 'hidden', position: 'relative' }}>
      {screen === 'list' && <ScreenList ctx={ctx} />}
      {screen === 'start' && <ScreenStart ctx={ctx} />}
      {screen === 'nav' && <ScreenNav ctx={ctx} />}
      {screen === 'paused' && <ScreenPaused ctx={ctx} />}
      {screen === 'complete' && <ScreenComplete ctx={ctx} />}
    </div>
  );
}

// ── STATUS BAR (dark or light) ─────────────────────────────────────────
function StatusBar({ dark = false }) {
  const c = dark ? RR.textOnInk : RR.textHigh;
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '14px 28px 6px', fontFamily: RR.display, fontSize: 15, fontWeight: 700, color: c, letterSpacing: -0.2 }}>
      <span>9:41</span>
      <div style={{ display: 'flex', gap: 5, alignItems: 'center' }}>
        <svg width="16" height="10" viewBox="0 0 16 10"><rect x="0" y="6" width="2.5" height="4" fill={c} rx="0.5"/><rect x="4" y="4" width="2.5" height="6" fill={c} rx="0.5"/><rect x="8" y="2" width="2.5" height="8" fill={c} rx="0.5"/><rect x="12" y="0" width="2.5" height="10" fill={c} rx="0.5"/></svg>
        <svg width="22" height="10" viewBox="0 0 22 10"><rect x="0.5" y="0.5" width="18" height="9" rx="2" fill="none" stroke={c}/><rect x="2" y="2" width="15" height="6" fill={c} rx="0.8"/><rect x="19.5" y="3" width="1.5" height="4" fill={c} rx="0.5"/></svg>
      </div>
    </div>
  );
}

// ── HOME INDICATOR (to match iOS frames) ───────────────────────────────
function HomeIndicator({ dark = false }) {
  return (
    <div style={{ position: 'absolute', bottom: 8, left: 0, right: 0, display: 'flex', justifyContent: 'center', pointerEvents: 'none', zIndex: 99 }}>
      <div style={{ width: 134, height: 5, borderRadius: 100, background: dark ? 'rgba(245,239,227,0.7)' : 'rgba(22,19,15,0.3)' }} />
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════
// SCREEN 1: ROUTE LIST
// ══════════════════════════════════════════════════════════════════════
function ScreenList({ ctx }) {
  const keys = Object.keys(MOCK_ROUTES).sort((a,b) => MOCK_ROUTES[b].savedAt - MOCK_ROUTES[a].savedAt);
  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: RR.paper }}>
      <StatusBar />
      {/* Header */}
      <div style={{ padding: '14px 24px 24px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 22 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ width: 32, height: 32, borderRadius: 7, background: RR.ink, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <div style={{ width: 10, height: 10, background: RR.amber, borderRadius: 1, transform: 'rotate(45deg)' }} />
            </div>
            <div style={{ fontFamily: RR.display, fontSize: 16, fontWeight: 800, letterSpacing: -0.3 }}>ROUTE<span style={{ color: RR.amberDeep }}>·</span>RUNNER</div>
          </div>
          <div style={{ fontFamily: RR.mono, fontSize: 11, color: RR.textLow, textTransform: 'uppercase', letterSpacing: 0.5 }}>Mon · Apr 21</div>
        </div>
        <div style={{ fontFamily: RR.display, fontSize: 44, fontWeight: 800, lineHeight: 0.95, letterSpacing: -0.02, color: RR.textHigh }}>Morning,<br/>Taylor.</div>
        <div style={{ marginTop: 10, fontSize: 15, color: RR.textMid }}>3 routes ready. Tap one to roll.</div>
      </div>

      {/* Route cards */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '0 16px 100px' }}>
        {keys.map((key) => {
          const r = MOCK_ROUTES[key];
          const prog = MOCK_PROGRESS[key];
          const isResume = !!prog;
          return (
            <button key={key} onClick={() => ctx.openRoute(key)}
              style={{ display: 'block', width: '100%', textAlign: 'left', marginBottom: 10, padding: '18px 18px 16px', background: isResume ? RR.ink : '#FFFAEE', border: `1.5px solid ${isResume ? RR.ink : RR.line}`, borderRadius: 14, position: 'relative', overflow: 'hidden' }}>
              {isResume && <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 3, background: RR.amber }} />}
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 4 }}>
                    {isResume && <span style={{ fontFamily: RR.mono, fontSize: 9, fontWeight: 600, color: RR.amber, background: 'rgba(232,168,56,0.15)', padding: '2.5px 6px', borderRadius: 3, letterSpacing: 0.8, textTransform: 'uppercase' }}>● In Progress</span>}
                    {!isResume && <span style={{ fontFamily: RR.mono, fontSize: 9, fontWeight: 600, color: RR.textLow, letterSpacing: 0.8, textTransform: 'uppercase' }}>Ready</span>}
                  </div>
                  <div style={{ fontFamily: RR.display, fontSize: 22, fontWeight: 700, color: isResume ? RR.textOnInk : RR.textHigh, letterSpacing: -0.4 }}>{r.name}</div>
                </div>
                <div style={{ width: 34, height: 34, borderRadius: 17, background: isResume ? RR.amber : RR.ink, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M5 2l5 5-5 5" stroke={isResume ? RR.ink : RR.paper} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"/></svg>
                </div>
              </div>

              {/* stats row */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 2, borderTop: `1px solid ${isResume ? RR.ink3 : RR.line}`, paddingTop: 12 }}>
                <Stat label="Stops" value={isResume ? `${prog.currentStopIndex}/${r.stopCount}` : r.stopCount} dark={isResume} />
                <Stat label="Time" value={fmtHours(r.estimate.totalHours)} dark={isResume} />
                <Stat label="Charge" value={`$${Math.round(r.estimate.suggestedPrice)}`} dark={isResume} accent={!isResume} />
              </div>
            </button>
          );
        })}

        {/* system info card */}
        <div style={{ marginTop: 12, padding: '14px 16px', background: 'transparent', border: `1px dashed ${RR.line}`, borderRadius: 10, fontSize: 13, color: RR.textMid, lineHeight: 1.4 }}>
          <span style={{ fontFamily: RR.mono, fontSize: 10, color: RR.amberDeep, fontWeight: 600, letterSpacing: 0.8, textTransform: 'uppercase', display: 'block', marginBottom: 3 }}>Route Notes</span>
          Routes are auto-optimized from your starting location once you tap Start.
        </div>
      </div>
      <HomeIndicator />
    </div>
  );
}

function Stat({ label, value, dark, accent }) {
  return (
    <div>
      <div style={{ fontFamily: RR.mono, fontSize: 9.5, fontWeight: 600, color: dark ? RR.textOnInk3 : RR.textLow, textTransform: 'uppercase', letterSpacing: 0.8 }}>{label}</div>
      <div className="num" style={{ fontFamily: RR.display, fontSize: 20, fontWeight: 700, color: accent ? RR.amberDeep : (dark ? RR.textOnInk : RR.textHigh), lineHeight: 1.1, marginTop: 2, letterSpacing: -0.4 }}>{value}</div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════
// SCREEN 2: START (ROUTE PREVIEW)
// ══════════════════════════════════════════════════════════════════════
function ScreenStart({ ctx }) {
  const r = ctx.route; if (!r) return null;
  const e = r.estimate;
  const isResume = MOCK_PROGRESS[ctx.routeKey] != null;
  const remaining = r.stopCount - ctx.stopIdx;

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: RR.paper }}>
      <StatusBar />
      {/* Top bar */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 16px' }}>
        <button onClick={() => ctx.setScreen('list')} style={{ width: 40, height: 40, borderRadius: 10, background: '#FFFAEE', border: `1.5px solid ${RR.line}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M9 2L3 7l6 5" stroke={RR.textHigh} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"/></svg>
        </button>
        <div style={{ fontFamily: RR.mono, fontSize: 10, color: RR.textLow, letterSpacing: 0.8, textTransform: 'uppercase' }}>Route Preview</div>
        <button style={{ width: 40, height: 40, borderRadius: 10, background: '#FFFAEE', border: `1.5px solid ${RR.line}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <svg width="4" height="16" viewBox="0 0 4 16"><circle cx="2" cy="2" r="1.6" fill={RR.textHigh}/><circle cx="2" cy="8" r="1.6" fill={RR.textHigh}/><circle cx="2" cy="14" r="1.6" fill={RR.textHigh}/></svg>
        </button>
      </div>

      <div style={{ padding: '12px 24px 6px' }}>
        <div style={{ fontFamily: RR.display, fontSize: 30, fontWeight: 800, letterSpacing: -0.6, lineHeight: 1.05, color: RR.textHigh }}>{r.name}</div>
        <div style={{ fontSize: 14, color: RR.textMid, marginTop: 4 }}>{r.stopCount} stops · auto-optimized for fastest drive</div>
      </div>

      {/* Estimate strip */}
      <div style={{ margin: '14px 16px 10px', background: RR.ink, borderRadius: 14, padding: '18px 4px', display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', position: 'relative' }}>
        <StripStat label="Stops" value={r.stopCount} />
        <StripStat label="Est. Time" value={fmtHours(e.totalHours)} div />
        <StripStat label="Charge" value={`$${Math.round(e.suggestedPrice)}`} div accent />
      </div>

      {/* Stop list */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '6px 16px 220px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 6px 10px' }}>
          <span style={{ fontFamily: RR.mono, fontSize: 10, color: RR.textLow, letterSpacing: 0.8, textTransform: 'uppercase', fontWeight: 600 }}>Delivery Order</span>
          <span style={{ fontFamily: RR.mono, fontSize: 11, color: RR.amberDeep, fontWeight: 600 }}>↓ OPTIMIZED</span>
        </div>
        <div style={{ background: '#FFFAEE', border: `1.5px solid ${RR.line}`, borderRadius: 14, overflow: 'hidden' }}>
          {r.stops.map((s, i) => {
            const done = isResume && i < ctx.stopIdx;
            const active = isResume && i === ctx.stopIdx;
            return (
              <div key={i} style={{ display: 'flex', padding: '11px 12px 11px 14px', alignItems: 'center', gap: 12, borderBottom: i < r.stops.length - 1 ? `1px solid ${RR.paper2}` : 'none', opacity: done ? 0.45 : 1, position: 'relative' }}>
                {active && <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 3, background: RR.amber }} />}
                <div style={{ width: 28, height: 28, borderRadius: 7, background: done ? RR.moss : (active ? RR.amber : RR.paper2), display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, fontFamily: RR.mono, fontSize: 12, fontWeight: 700, color: done || active ? RR.ink : RR.textMid }}>
                  {done ? <svg width="12" height="12" viewBox="0 0 12 12"><path d="M2 6l3 3 5-6" stroke={RR.paper} strokeWidth="2.2" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg> : (i + 1)}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 14, fontWeight: 600, color: RR.textHigh, textDecoration: done ? 'line-through' : 'none', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{s.name}</div>
                  <div style={{ fontSize: 11.5, color: RR.textLow, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{s.address}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Bottom action */}
      <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: '20px 16px 34px', background: `linear-gradient(to top, ${RR.paper} 60%, rgba(245,239,227,0))` }}>
        {isResume && (
          <div style={{ marginBottom: 10, padding: '10px 14px', background: 'rgba(232,168,56,0.12)', border: `1px solid ${RR.amber}`, borderRadius: 10, fontSize: 12, color: RR.textHigh, display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ width: 6, height: 6, borderRadius: 3, background: RR.amber, animation: 'rr-pulse 1.6s infinite' }} />
            <span><strong style={{fontWeight: 700}}>Resuming —</strong> {ctx.delivered} delivered, {remaining} left</span>
          </div>
        )}
        <button onClick={ctx.startRoute} style={{ width: '100%', padding: '18px', background: RR.amber, color: RR.ink, borderRadius: 14, fontFamily: RR.display, fontSize: 18, fontWeight: 800, letterSpacing: 0.3, textTransform: 'uppercase', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, boxShadow: `0 4px 0 ${RR.amberDeep}, 0 8px 20px rgba(198,126,26,0.25)` }}>
          <svg width="18" height="18" viewBox="0 0 18 18"><polygon points="4 2 15 9 4 16" fill={RR.ink}/></svg>
          {isResume ? 'Resume Route' : 'Start Route'}
        </button>
      </div>
      <HomeIndicator />
    </div>
  );
}

function StripStat({ label, value, div, accent }) {
  return (
    <div style={{ textAlign: 'center', padding: '0 8px', borderLeft: div ? `1px solid ${RR.ink3}` : 'none' }}>
      <div style={{ fontFamily: RR.mono, fontSize: 9.5, color: RR.textOnInk3, letterSpacing: 0.8, textTransform: 'uppercase', fontWeight: 600 }}>{label}</div>
      <div className="num" style={{ fontFamily: RR.display, fontSize: 22, fontWeight: 800, color: accent ? RR.amber : RR.textOnInk, letterSpacing: -0.5, marginTop: 3 }}>{value}</div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════
// SCREEN 3: NAV (driving)
// ══════════════════════════════════════════════════════════════════════
function ScreenNav({ ctx }) {
  const stop = ctx.stops[ctx.stopIdx]; if (!stop) return null;
  const total = ctx.stops.length;
  const pct = ((ctx.stopIdx) / total) * 100;

  return (
    <div style={{ position: 'relative', height: '100%', background: '#E8E0CC', overflow: 'hidden' }}>
      {/* Fake map */}
      <FakeMap />

      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, zIndex: 20 }}>
        <StatusBar dark={false} />
      </div>

      {/* TOP: Turn instruction */}
      <div style={{ position: 'absolute', top: 48, left: 14, right: 14, zIndex: 10, display: 'flex', gap: 10, background: RR.ink, borderRadius: 14, padding: '12px 14px', alignItems: 'center', boxShadow: '0 6px 20px rgba(0,0,0,0.22)' }}>
        <div style={{ width: 52, height: 52, borderRadius: 11, background: RR.amber, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke={RR.ink} strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 4 17 4 17 16"/><polyline points="13 8 17 4 21 8"/></svg>
        </div>
        <div style={{ flex: 1 }}>
          <div className="num" style={{ fontFamily: RR.display, fontSize: 24, fontWeight: 800, color: RR.amber, lineHeight: 1, letterSpacing: -0.3 }}>0.3 mi</div>
          <div style={{ fontSize: 13.5, color: RR.textOnInk, fontWeight: 500, marginTop: 3, lineHeight: 1.2 }}>Turn right onto Cahaba Road</div>
        </div>
      </div>

      {/* Progress badge top-right */}
      <div style={{ position: 'absolute', top: 118, right: 14, zIndex: 10, background: RR.paper, borderRadius: 10, padding: '7px 10px', border: `1.5px solid ${RR.ink}`, boxShadow: '0 3px 8px rgba(0,0,0,0.15)' }}>
        <div style={{ fontFamily: RR.mono, fontSize: 9.5, fontWeight: 600, color: RR.textLow, textTransform: 'uppercase', letterSpacing: 0.6 }}>Stop</div>
        <div className="num" style={{ fontFamily: RR.display, fontSize: 17, fontWeight: 800, color: RR.textHigh, lineHeight: 1 }}>
          {ctx.stopIdx + 1}<span style={{ color: RR.textLow }}>/{total}</span>
        </div>
      </div>

      {/* Voice toggle */}
      <button onClick={() => ctx.setVoiceOn(v => !v)} style={{ position: 'absolute', top: 180, right: 14, zIndex: 10, width: 44, height: 44, borderRadius: 22, background: ctx.voiceOn ? RR.ink : RR.paper, border: ctx.voiceOn ? `1.5px solid ${RR.ink3}` : `1.5px solid ${RR.line}`, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 3px 8px rgba(0,0,0,0.15)' }}>
        {ctx.voiceOn ? (
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={RR.amber} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" fill={RR.amber}/><path d="M19 4.9a10 10 0 010 14.1M15.5 8.5a5 5 0 010 7"/></svg>
        ) : (
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={RR.textMid} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="22" y1="9" x2="16" y2="15"/><line x1="16" y1="9" x2="22" y2="15"/></svg>
        )}
      </button>

      {/* BOTTOM CARD */}
      <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, background: RR.paper, borderTopLeftRadius: 22, borderTopRightRadius: 22, paddingBottom: 34, boxShadow: '0 -4px 24px rgba(0,0,0,0.12)', zIndex: 10 }}>
        {/* Progress bar */}
        <div style={{ height: 4, background: RR.paper2, position: 'relative', borderTopLeftRadius: 22, borderTopRightRadius: 22, overflow: 'hidden' }}>
          <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: `${pct}%`, background: RR.amber }} />
        </div>

        <div style={{ padding: '14px 18px 4px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6 }}>
            <div style={{ width: 7, height: 7, borderRadius: 4, background: RR.amber, animation: 'rr-pulse 1.4s infinite' }} />
            <span style={{ fontFamily: RR.mono, fontSize: 10, color: RR.amberDeep, fontWeight: 600, letterSpacing: 0.8, textTransform: 'uppercase' }}>Heading To</span>
          </div>
          <div style={{ fontFamily: RR.display, fontSize: 22, fontWeight: 800, color: RR.textHigh, letterSpacing: -0.4, lineHeight: 1.1 }}>{stop.name}</div>
          <div style={{ fontSize: 13, color: RR.textMid, marginTop: 3 }}>{stop.address}</div>

          {/* Chips */}
          <div style={{ display: 'flex', gap: 7, marginTop: 12, alignItems: 'center' }}>
            <Chip icon="clock" label="4 min" />
            <Chip icon="ruler" label="0.8 mi" />
            <div style={{ flex: 1 }} />
            <button style={{ padding: '7px 12px', border: `1.5px solid ${RR.line}`, borderRadius: 8, fontSize: 12, fontWeight: 600, color: RR.textHigh, display: 'flex', alignItems: 'center', gap: 6, background: '#FFFAEE' }}>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
              Maps
            </button>
          </div>
        </div>

        {/* Actions */}
        <div style={{ padding: '14px 14px 0', display: 'grid', gridTemplateColumns: '2fr 1fr 1fr', gap: 8 }}>
          <button onClick={ctx.markDelivered} style={{ padding: '18px 12px', background: RR.moss, color: RR.paper, borderRadius: 12, fontFamily: RR.display, fontSize: 16, fontWeight: 800, letterSpacing: 0.3, textTransform: 'uppercase', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, boxShadow: `0 3px 0 ${RR.mossDeep}` }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={RR.paper} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
            Delivered
          </button>
          <button onClick={ctx.skip} style={{ padding: '18px 8px', background: '#FFFAEE', border: `1.5px solid ${RR.line}`, color: RR.textHigh, borderRadius: 12, fontFamily: RR.display, fontSize: 13, fontWeight: 700, letterSpacing: 0.3, textTransform: 'uppercase' }}>Skip</button>
          <button onClick={ctx.pause} style={{ padding: '18px 8px', background: '#FFFAEE', border: `1.5px solid ${RR.line}`, color: RR.textHigh, borderRadius: 12, fontFamily: RR.display, fontSize: 13, fontWeight: 700, letterSpacing: 0.3, textTransform: 'uppercase' }}>Pause</button>
        </div>
      </div>
      <HomeIndicator />
    </div>
  );
}

function Chip({ icon, label }) {
  const icons = {
    clock: <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round"><circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 16 14"/></svg>,
    ruler: <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 7l5-5 15 15-5 5z"/><path d="M7 12l2 2M12 7l2 2M5 15l2 2M15 5l2 2"/></svg>,
  };
  return (
    <div className="num" style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '6px 9px', background: RR.amberSoft, borderRadius: 7, fontSize: 12, fontWeight: 600, color: RR.ink, fontFamily: RR.mono }}>
      {icons[icon]}{label}
    </div>
  );
}

// Fake map — stylized OSM-ish ground
function FakeMap() {
  return (
    <div style={{ position: 'absolute', inset: 0, background: '#E8E0CC', overflow: 'hidden' }}>
      <svg width="100%" height="100%" viewBox="0 0 400 700" preserveAspectRatio="xMidYMid slice" style={{ display: 'block' }}>
        <defs>
          <pattern id="roads" width="80" height="80" patternUnits="userSpaceOnUse">
            <rect width="80" height="80" fill="#E8E0CC"/>
            <path d="M0 40 L80 40 M40 0 L40 80" stroke="#D6CAB1" strokeWidth="1.2"/>
          </pattern>
        </defs>
        <rect width="400" height="700" fill="url(#roads)"/>
        {/* Park / river */}
        <path d="M-10 180 Q 120 220 200 180 T 410 190 L 410 260 Q 300 230 180 260 T -10 250 Z" fill="#C7D6AE" opacity="0.7"/>
        <path d="M-10 460 Q 140 520 260 470 T 410 490 L 410 520 Q 280 500 160 530 T -10 510 Z" fill="#B8CFE5" opacity="0.55"/>
        {/* Major roads */}
        <path d="M0 380 Q 200 360 400 390" stroke="#F5EFE3" strokeWidth="22" fill="none" strokeLinecap="round"/>
        <path d="M0 380 Q 200 360 400 390" stroke="#DDD2BC" strokeWidth="24" fill="none" strokeLinecap="round" opacity="0.5"/>
        <path d="M180 0 Q 200 340 260 700" stroke="#F5EFE3" strokeWidth="18" fill="none" strokeLinecap="round"/>
        {/* Route line */}
        <path d="M100 600 Q 170 450 220 420 T 310 260" stroke={RR.amber} strokeWidth="7" fill="none" strokeLinecap="round" strokeDasharray="0"/>
        <path d="M100 600 Q 170 450 220 420 T 310 260" stroke={RR.ink} strokeWidth="2" fill="none" strokeLinecap="round" opacity="0.2"/>
        {/* Driver marker */}
        <g transform="translate(100,600)">
          <circle r="22" fill={RR.amber} opacity="0.25"/>
          <circle r="11" fill="#fff"/>
          <circle r="8" fill={RR.ink}/>
          <circle r="4" fill={RR.amber}/>
        </g>
        {/* Destination marker */}
        <g transform="translate(310,260)">
          <path d="M0,-26 C -12,-26 -18,-16 -18,-8 C -18,4 0,20 0,20 C 0,20 18,4 18,-8 C 18,-16 12,-26 0,-26 Z" fill={RR.rust} stroke={RR.ink} strokeWidth="2"/>
          <circle cx="0" cy="-10" r="6" fill={RR.paper}/>
          <text x="0" y="-6" fontFamily={RR.mono} fontSize="9" fontWeight="700" fill={RR.ink} textAnchor="middle">5</text>
        </g>
      </svg>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════
// SCREEN 4: PAUSED
// ══════════════════════════════════════════════════════════════════════
function ScreenPaused({ ctx }) {
  const total = ctx.stops.length;
  const remaining = total - ctx.stopIdx;
  const nextStop = ctx.stops[ctx.stopIdx];
  const pct = (ctx.delivered / total) * 100;

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: RR.ink, color: RR.textOnInk }}>
      <StatusBar dark />
      <div style={{ padding: '14px 24px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ width: 7, height: 7, borderRadius: 4, background: RR.amber, animation: 'rr-pulse 1.6s infinite' }} />
          <span style={{ fontFamily: RR.mono, fontSize: 10, color: RR.amber, fontWeight: 600, letterSpacing: 0.8, textTransform: 'uppercase' }}>Paused</span>
        </div>
        <div style={{ fontFamily: RR.display, fontSize: 38, fontWeight: 800, marginTop: 12, lineHeight: 0.95, letterSpacing: -0.02 }}>Taking a<br/>breather.</div>
        <div style={{ marginTop: 10, fontSize: 14, color: RR.textOnInk2, maxWidth: 280 }}>Your progress is saved. Close the app, come back whenever. The route will be waiting.</div>
      </div>

      {/* Big progress ring */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '0 24px' }}>
        <div style={{ position: 'relative', width: 220, height: 220 }}>
          <svg width="220" height="220" viewBox="0 0 220 220" style={{ position: 'absolute', inset: 0, transform: 'rotate(-90deg)' }}>
            <circle cx="110" cy="110" r="92" fill="none" stroke={RR.ink3} strokeWidth="14"/>
            <circle cx="110" cy="110" r="92" fill="none" stroke={RR.amber} strokeWidth="14" strokeLinecap="round"
              strokeDasharray={`${2 * Math.PI * 92}`} strokeDashoffset={`${2 * Math.PI * 92 * (1 - pct/100)}`} />
          </svg>
          <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
            <div className="num display" style={{ fontSize: 72, fontWeight: 800, lineHeight: 1, color: RR.amber, letterSpacing: -0.04 }}>{ctx.delivered}</div>
            <div style={{ fontFamily: RR.mono, fontSize: 11, color: RR.textOnInk3, textTransform: 'uppercase', letterSpacing: 0.8, fontWeight: 600, marginTop: 2 }}>of {total} delivered</div>
          </div>
        </div>

        <div style={{ width: '100%', marginTop: 26, padding: '14px 16px', background: RR.ink2, border: `1px solid ${RR.ink3}`, borderRadius: 12 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <div style={{ fontFamily: RR.mono, fontSize: 9.5, color: RR.textOnInk3, textTransform: 'uppercase', letterSpacing: 0.8, fontWeight: 600 }}>Up Next · Stop {ctx.stopIdx + 1}</div>
              <div style={{ fontSize: 16, fontWeight: 700, color: RR.textOnInk, marginTop: 3 }}>{nextStop ? nextStop.name : '—'}</div>
            </div>
            <div className="num" style={{ fontFamily: RR.display, fontSize: 26, fontWeight: 800, color: RR.amber }}>{remaining}<span style={{ fontSize: 12, color: RR.textOnInk3, fontWeight: 500, marginLeft: 4 }}>left</span></div>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div style={{ padding: '16px 16px 34px' }}>
        <button onClick={ctx.resume} style={{ width: '100%', padding: '18px', background: RR.amber, color: RR.ink, borderRadius: 14, fontFamily: RR.display, fontSize: 18, fontWeight: 800, letterSpacing: 0.3, textTransform: 'uppercase', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, boxShadow: `0 4px 0 ${RR.amberDeep}` }}>
          <svg width="18" height="18" viewBox="0 0 18 18"><polygon points="4 2 15 9 4 16" fill={RR.ink}/></svg>
          Resume
        </button>
        <button onClick={ctx.endTrip} style={{ width: '100%', padding: '14px', marginTop: 10, background: 'transparent', color: RR.textOnInk2, borderRadius: 12, border: `1.5px solid ${RR.ink3}`, fontFamily: RR.display, fontSize: 13, fontWeight: 700, letterSpacing: 0.5, textTransform: 'uppercase' }}>End Trip</button>
      </div>
      <HomeIndicator dark />
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════
// SCREEN 5: COMPLETE
// ══════════════════════════════════════════════════════════════════════
function ScreenComplete({ ctx }) {
  const e = ctx.route ? ctx.route.estimate : null;
  const actualHours = e ? e.totalHours * 0.88 : 3;
  const actualLabor = actualHours * 20;
  const actualGas = e ? e.totalMiles * 0.18 : 5;
  const actualCost = actualLabor + actualGas;
  const profit = e ? e.suggestedPrice - actualCost : 0;

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: RR.paper, overflow: 'hidden' }}>
      <StatusBar />
      <div style={{ flex: 1, overflowY: 'auto', padding: '8px 16px 120px' }}>
        {/* Hero */}
        <div style={{ textAlign: 'center', padding: '24px 8px 22px' }}>
          <div style={{ display: 'inline-block', padding: '6px 12px', background: RR.moss, color: RR.paper, borderRadius: 6, fontFamily: RR.mono, fontSize: 11, fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase' }}>Complete</div>
          <div style={{ fontFamily: RR.display, fontSize: 44, fontWeight: 800, letterSpacing: -0.02, lineHeight: 0.95, marginTop: 14, color: RR.textHigh }}>Nice work,<br/>Taylor.</div>
          <div style={{ marginTop: 8, fontSize: 14, color: RR.textMid }}>{ctx.route ? ctx.route.name : ''}</div>
        </div>

        {/* Big stats */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 6, marginBottom: 14 }}>
          <BigStat value={ctx.delivered} label="Delivered" color={RR.moss} />
          <BigStat value={ctx.skipped} label="Skipped" color={RR.rust} />
          <BigStat value={fmtHours(actualHours)} label="Total Time" />
        </div>

        {/* Financial breakdown */}
        <div style={{ background: RR.ink, color: RR.textOnInk, borderRadius: 16, padding: '18px 18px 20px', marginTop: 8 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
            <div style={{ fontFamily: RR.mono, fontSize: 10, color: RR.amber, fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase' }}>Trip Ledger</div>
            <div style={{ fontFamily: RR.mono, fontSize: 10, color: RR.textOnInk3, fontWeight: 600, letterSpacing: 0.6 }}>#{ctx.routeKey ? ctx.routeKey.slice(0,2).toUpperCase() : 'RR'}-{String(Math.floor(Math.random()*900)+100)}</div>
          </div>

          {/* Big profit */}
          <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 18, paddingBottom: 14, borderBottom: `1px dashed ${RR.ink3}` }}>
            <div>
              <div style={{ fontFamily: RR.mono, fontSize: 10.5, color: RR.textOnInk3, textTransform: 'uppercase', letterSpacing: 0.8, fontWeight: 600 }}>Profit</div>
              <div className="num display" style={{ fontSize: 56, fontWeight: 800, color: profit > 0 ? RR.amber : RR.rust, lineHeight: 0.95, letterSpacing: -0.04, marginTop: 2 }}>${Math.round(profit)}</div>
            </div>
            <div style={{ textAlign: 'right', paddingBottom: 6 }}>
              <div style={{ fontFamily: RR.mono, fontSize: 10.5, color: RR.textOnInk3, textTransform: 'uppercase', letterSpacing: 0.8, fontWeight: 600 }}>Charged</div>
              <div className="num display" style={{ fontSize: 26, fontWeight: 800, color: RR.textOnInk, letterSpacing: -0.4, marginTop: 2 }}>${e ? Math.round(e.suggestedPrice) : 0}</div>
            </div>
          </div>

          {/* Line items */}
          <LedgerRow label={`Driver pay  ·  ${fmtHours(actualHours)} @ $20/hr`} value={`$${actualLabor.toFixed(0)}`} />
          <LedgerRow label={`Gas  ·  ${e ? e.totalMiles.toFixed(0) : 0} mi @ $0.18`} value={`$${actualGas.toFixed(2)}`} />
          <LedgerRow label="Cost total" value={`$${actualCost.toFixed(2)}`} strong />

          <div style={{ marginTop: 14, padding: '10px 12px', background: RR.ink2, border: `1px solid ${RR.ink3}`, borderRadius: 8, fontSize: 11.5, color: RR.textOnInk2, lineHeight: 1.4 }}>
            <span style={{ color: RR.amber, fontFamily: RR.mono, fontWeight: 600, fontSize: 10, letterSpacing: 0.8, textTransform: 'uppercase' }}>Next time →</span>{' '}
            Charge at least <strong style={{ color: RR.textOnInk, fontWeight: 700 }}>${Math.round(actualCost * 1.25)}</strong> (cost + 25% cushion).
          </div>
        </div>
      </div>

      <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: '16px 16px 34px', background: `linear-gradient(to top, ${RR.paper} 70%, rgba(245,239,227,0))` }}>
        <button onClick={ctx.newTrip} style={{ width: '100%', padding: '18px', background: RR.ink, color: RR.paper, borderRadius: 14, fontFamily: RR.display, fontSize: 17, fontWeight: 800, letterSpacing: 0.3, textTransform: 'uppercase' }}>Back to Routes</button>
      </div>
      <HomeIndicator />
    </div>
  );
}

function BigStat({ value, label, color }) {
  return (
    <div style={{ background: '#FFFAEE', border: `1.5px solid ${RR.line}`, borderRadius: 12, padding: '14px 10px', textAlign: 'center', position: 'relative', overflow: 'hidden' }}>
      {color && <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 3, background: color }} />}
      <div className="num display" style={{ fontSize: 30, fontWeight: 800, color: RR.textHigh, letterSpacing: -0.5, lineHeight: 1 }}>{value}</div>
      <div style={{ fontFamily: RR.mono, fontSize: 9.5, fontWeight: 600, color: RR.textLow, textTransform: 'uppercase', letterSpacing: 0.8, marginTop: 4 }}>{label}</div>
    </div>
  );
}

function LedgerRow({ label, value, strong }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', padding: '6px 0', fontSize: 13 }}>
      <span style={{ color: strong ? RR.textOnInk : RR.textOnInk2, fontWeight: strong ? 700 : 500 }}>{label}</span>
      <span className="num" style={{ fontFamily: RR.mono, fontSize: strong ? 15 : 13, fontWeight: strong ? 700 : 500, color: RR.textOnInk }}>{value}</span>
    </div>
  );
}

// ─ helpers ────
function fmtHours(h) {
  const hrs = Math.floor(h);
  const mins = Math.round((h - hrs) * 60);
  if (hrs === 0) return mins + 'm';
  return hrs + 'h ' + (mins > 0 ? mins + 'm' : '');
}

Object.assign(window, { DriverApp, fmtHours });
